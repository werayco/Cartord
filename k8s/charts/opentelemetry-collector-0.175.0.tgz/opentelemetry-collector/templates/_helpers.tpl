{{/*
Expand the name of the chart.
*/}}
{{- define "opentelemetry-collector.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "opentelemetry-collector.lowercase_chartname" -}}
{{- default .Chart.Name | lower }}
{{- end }}

{{/*
Get component name
*/}}
{{- define "opentelemetry-collector.component" -}}
{{- if eq .Values.mode "deployment" -}}
component: standalone-collector
{{- end -}}
{{- if eq .Values.mode "daemonset" -}}
component: agent-collector
{{- end -}}
{{- if eq .Values.mode "statefulset" -}}
component: statefulset-collector
{{- end -}}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "opentelemetry-collector.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "opentelemetry-collector.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "opentelemetry-collector.labels" -}}
helm.sh/chart: {{ include "opentelemetry-collector.chart" . }}
{{ include "opentelemetry-collector.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: opentelemetry-collector
{{- if eq .Values.mode "deployment" }}
app.kubernetes.io/component: standalone-collector
{{- end -}}
{{- if eq .Values.mode "daemonset" }}
app.kubernetes.io/component: agent-collector
{{- end -}}
{{- if eq .Values.mode "statefulset" }}
app.kubernetes.io/component: statefulset-collector
{{- end -}}
{{- if .Values.additionalLabels }}
{{ tpl (.Values.additionalLabels | toYaml) . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "opentelemetry-collector.selectorLabels" -}}
app.kubernetes.io/name: {{ include "opentelemetry-collector.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "opentelemetry-collector.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "opentelemetry-collector.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{/*
Create the name of the clusterRole to use
*/}}
{{- define "opentelemetry-collector.clusterRoleName" -}}
{{- default (include "opentelemetry-collector.fullname" .) .Values.clusterRole.name }}
{{- end }}

{{/*
Create the name of the clusterRoleBinding to use
*/}}
{{- define "opentelemetry-collector.clusterRoleBindingName" -}}
{{- default (include "opentelemetry-collector.fullname" .) .Values.clusterRole.clusterRoleBinding.name }}
{{- end }}

{{- define "opentelemetry-collector.podAnnotations" -}}
{{- if .Values.podAnnotations }}
{{- tpl (.Values.podAnnotations | toYaml) . }}
{{- end }}
{{- if and (not .Values.securityContext) .Values.presets.profiling.enabled (semverCompare "< 1.30-0" .Capabilities.KubeVersion.Version) }}
container.apparmor.security.beta.kubernetes.io/{{ include "opentelemetry-collector.lowercase_chartname" . }}: unconfined
{{- end }}
{{- end }}

{{- define "opentelemetry-collector.podLabels" -}}
{{- if .Values.podLabels }}
{{- tpl (.Values.podLabels | toYaml) . }}
{{- end }}
{{- end }}

{{/*
Return the appropriate apiVersion for podDisruptionBudget.
*/}}
{{- define "podDisruptionBudget.apiVersion" -}}
  {{- if and (.Capabilities.APIVersions.Has "policy/v1") (semverCompare ">= 1.21-0" .Capabilities.KubeVersion.Version) -}}
    {{- print "policy/v1" -}}
  {{- else -}}
    {{- print "policy/v1beta1" -}}
  {{- end -}}
{{- end -}}

{{/*
Compute Service creation on mode
*/}}
{{- define "opentelemetry-collector.serviceEnabled" }}
  {{- $serviceEnabled := true }}
  {{- if not (eq (toString .Values.service.enabled) "<nil>") }}
    {{- $serviceEnabled = .Values.service.enabled -}}
  {{- end }}
  {{- if and (eq .Values.mode "daemonset") (not .Values.service.enabled) }}
    {{- $serviceEnabled = false -}}
  {{- end }}

  {{- print $serviceEnabled }}
{{- end -}}


{{/*
Compute InternalTrafficPolicy on Service creation
*/}}
{{- define "opentelemetry-collector.serviceInternalTrafficPolicy" }}
  {{- if and (eq .Values.mode "daemonset") (eq .Values.service.enabled true) }}
    {{- print (.Values.service.internalTrafficPolicy | default "Local") -}}
  {{- else }}
    {{- print (.Values.service.internalTrafficPolicy | default "Cluster") -}}
  {{- end }}
{{- end -}}

{{/*
Allow the release namespace to be overridden
*/}}
{{- define "opentelemetry-collector.namespace" -}}
  {{- if .Values.namespaceOverride -}}
    {{- .Values.namespaceOverride -}}
  {{- else -}}
    {{- .Release.Namespace -}}
  {{- end -}}
{{- end -}}

{{/*
  This helper converts the input value of memory to Bytes.
  Input needs to be a valid value as supported by k8s memory resource field.
 */}}
{{- define "opentelemetry-collector.convertMemToBytes" }}
  {{- $mem := lower . -}}
  {{- if hasSuffix "e" $mem -}}
    {{- $mem = mulf (trimSuffix "e" $mem | float64) 1e18 -}}
  {{- else if hasSuffix "ei" $mem -}}
    {{- $mem = mulf (trimSuffix "e" $mem | float64) 0x1p60 -}}
  {{- else if hasSuffix "p" $mem -}}
    {{- $mem = mulf (trimSuffix "p" $mem | float64) 1e15 -}}
  {{- else if hasSuffix "pi" $mem -}}
    {{- $mem = mulf (trimSuffix "pi" $mem | float64) 0x1p50 -}}
  {{- else if hasSuffix "t" $mem -}}
    {{- $mem = mulf (trimSuffix "t" $mem | float64) 1e12 -}}
  {{- else if hasSuffix "ti" $mem -}}
    {{- $mem = mulf (trimSuffix "ti" $mem | float64) 0x1p40 -}}
  {{- else if hasSuffix "g" $mem -}}
    {{- $mem = mulf (trimSuffix "g" $mem | float64) 1e9 -}}
  {{- else if hasSuffix "gi" $mem -}}
    {{- $mem = mulf (trimSuffix "gi" $mem | float64) 0x1p30 -}}
  {{- else if hasSuffix "m" $mem -}}
    {{- $mem = mulf (trimSuffix "m" $mem | float64) 1e6 -}}
  {{- else if hasSuffix "mi" $mem -}}
    {{- $mem = mulf (trimSuffix "mi" $mem | float64) 0x1p20 -}}
  {{- else if hasSuffix "k" $mem -}}
    {{- $mem = mulf (trimSuffix "k" $mem | float64) 1e3 -}}
  {{- else if hasSuffix "ki" $mem -}}
    {{- $mem = mulf (trimSuffix "ki" $mem | float64) 0x1p10 -}}
  {{- end }}
{{- $mem }}
{{- end }}

{{- define "opentelemetry-collector.gomemlimit" }}
{{- $memlimitBytes := include "opentelemetry-collector.convertMemToBytes" . | mulf 0.8 -}}
{{- printf "%dMiB" (divf $memlimitBytes 0x1p20 | floor | int64) -}}
{{- end }}

{{/*
Get HPA kind from mode.
The capitalization is important for StatefulSet.
*/}}
{{- define "opentelemetry-collector.hpaKind" -}}
{{- if eq .Values.mode "deployment" -}}
{{- print "Deployment" -}}
{{- end -}}
{{- if eq .Values.mode "statefulset" -}}
{{- print "StatefulSet" -}}
{{- end -}}
{{- end }}

{{/*
Get ConfigMap name if existingName is defined, otherwise use default name for generated config.
*/}}
{{- define "opentelemetry-collector.configName" -}}
  {{- if .Values.configMap.existingName -}}
    {{- tpl (.Values.configMap.existingName | toYaml) . }}
  {{- else }}
    {{- printf "%s%s" (include "opentelemetry-collector.fullname" .) (.configmapSuffix) }}
  {{- end -}}
{{- end }}

{{/*
Create ConfigMap checksum annotation if configMap.existingPath is defined, otherwise use default templates
*/}}
{{- define "opentelemetry-collector.configTemplateChecksumAnnotation" -}}
  {{- if .Values.configMap.existingPath -}}
  checksum/config: {{ include "opentelemetry-collector.configChecksum" (dict "context" . "path" (print "/" .Values.configMap.existingPath)) }}
  {{- else -}}
    {{- if eq .Values.mode "daemonset" -}}
    checksum/config: {{ include "opentelemetry-collector.configChecksum" (dict "context" . "path" "/configmap-agent.yaml") }}
    {{- else if eq .Values.mode "deployment" -}}
    checksum/config: {{ include "opentelemetry-collector.configChecksum" (dict "context" . "path" "/configmap.yaml") }}
    {{- else if eq .Values.mode "statefulset" -}}
    checksum/config: {{ include "opentelemetry-collector.configChecksum" (dict "context" . "path" "/configmap-statefulset.yaml") }}
    {{- end -}}
  {{- end }}
{{- end }}

{{/*
Hash only the data of a rendered ConfigMap, so that the chart labels on the manifest do not change the checksum
*/}}
{{- define "opentelemetry-collector.configChecksum" -}}
{{- pick (include (print .context.Template.BasePath .path) .context | fromYaml) "data" "stringData" | toYaml | sha256sum -}}
{{- end }}

{{- define "opentelemetry-collector.deprecatedComponentRenames" -}}
components:
  receivers:
    filelog: file_log
  processors:
    k8sattributes: k8s_attributes
  exporters:
    otlp: otlp_grpc
    otlphttp: otlp_http
detectors:
  k8snode: k8s_api
{{- end -}}

{{- define "opentelemetry-collector.deprecations" -}}
{{- $warnings := list -}}
{{- $renames := include "opentelemetry-collector.deprecatedComponentRenames" . | fromYaml -}}
{{- $rewriteEnabled := $.Values.rewriteDeprecatedComponentNames -}}
{{- range $oldName, $newName := (dig "components" "exporters" dict $renames) }}
  {{- $hasOldExporter := false -}}
  {{- range $key, $_ := $.Values.config.exporters }}
    {{- if or (eq $key $oldName) (hasPrefix (printf "%s/" $oldName) $key) }}
      {{- $hasOldExporter = true -}}
    {{- end }}
  {{- end }}
  {{- if $hasOldExporter }}
    {{- if $rewriteEnabled }}
      {{- $warnings = append $warnings (printf "[DEPRECATION] Exporter '%s' has been renamed to '%s'. Your config has been automatically rewritten for this release. Please update your values.yaml — auto-rewrite will be removed in a future release. See UPGRADING.md." $oldName $newName) -}}
    {{- else }}
      {{- $warnings = append $warnings (printf "[DEPRECATION] Exporter '%s' has been renamed to '%s'. Please update your values.yaml to use the new name — support for the old name will be removed in a future release. See UPGRADING.md." $oldName $newName) -}}
    {{- end }}
  {{- end }}
  {{- range $signal, $pipeline := $.Values.config.service.pipelines }}
    {{- if and $pipeline $pipeline.exporters }}
      {{- $hasOldPipelineRef := false -}}
      {{- range $pipeline.exporters }}
        {{- if or (eq . $oldName) (hasPrefix (printf "%s/" $oldName) .) }}
          {{- $hasOldPipelineRef = true -}}
        {{- end }}
      {{- end }}
      {{- if $hasOldPipelineRef }}
        {{- if $rewriteEnabled }}
          {{- $warnings = append $warnings (printf "[DEPRECATION] Pipeline '%s' references renamed exporter '%s'. It has been automatically rewritten to '%s' for this release. Please update your values.yaml — auto-rewrite will be removed in a future release. See UPGRADING.md." $signal $oldName $newName) -}}
        {{- else }}
          {{- $warnings = append $warnings (printf "[DEPRECATION] Pipeline '%s' references renamed exporter '%s'. Please update your values.yaml to use '%s' — support for the old name will be removed in a future release. See UPGRADING.md." $signal $oldName $newName) -}}
        {{- end }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
{{- range $oldName, $newName := (dig "components" "processors" dict $renames) }}
  {{- $hasOldProcessor := false -}}
  {{- range $key, $_ := $.Values.config.processors }}
    {{- if or (eq $key $oldName) (hasPrefix (printf "%s/" $oldName) $key) }}
      {{- $hasOldProcessor = true -}}
    {{- end }}
  {{- end }}
  {{- if $hasOldProcessor }}
    {{- if $rewriteEnabled }}
      {{- $warnings = append $warnings (printf "[DEPRECATION] Processor '%s' has been renamed to '%s'. Your config has been automatically rewritten for this release. Please update your values.yaml — auto-rewrite will be removed in a future release. See UPGRADING.md." $oldName $newName) -}}
    {{- else }}
      {{- $warnings = append $warnings (printf "[DEPRECATION] Processor '%s' has been renamed to '%s'. Please update your values.yaml to use the new name — support for the old name will be removed in a future release. See UPGRADING.md." $oldName $newName) -}}
    {{- end }}
  {{- end }}
  {{- range $signal, $pipeline := $.Values.config.service.pipelines }}
    {{- if and $pipeline $pipeline.processors }}
      {{- $hasOldPipelineRef := false -}}
      {{- range $pipeline.processors }}
        {{- if or (eq . $oldName) (hasPrefix (printf "%s/" $oldName) .) }}
          {{- $hasOldPipelineRef = true -}}
        {{- end }}
      {{- end }}
      {{- if $hasOldPipelineRef }}
        {{- if $rewriteEnabled }}
          {{- $warnings = append $warnings (printf "[DEPRECATION] Pipeline '%s' references renamed processor '%s'. It has been automatically rewritten to '%s' for this release. Please update your values.yaml — auto-rewrite will be removed in a future release. See UPGRADING.md." $signal $oldName $newName) -}}
        {{- else }}
          {{- $warnings = append $warnings (printf "[DEPRECATION] Pipeline '%s' references renamed processor '%s'. Please update your values.yaml to use '%s' — support for the old name will be removed in a future release. See UPGRADING.md." $signal $oldName $newName) -}}
        {{- end }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
{{- range $oldName, $newName := (dig "components" "receivers" dict $renames) }}
  {{- $hasOldReceiver := false -}}
  {{- range $key, $_ := $.Values.config.receivers }}
    {{- if or (eq $key $oldName) (hasPrefix (printf "%s/" $oldName) $key) }}
      {{- $hasOldReceiver = true -}}
    {{- end }}
  {{- end }}
  {{- if $hasOldReceiver }}
    {{- if $rewriteEnabled }}
      {{- $warnings = append $warnings (printf "[DEPRECATION] Receiver '%s' has been renamed to '%s'. Your config has been automatically rewritten for this release. Please update your values.yaml — auto-rewrite will be removed in a future release. See UPGRADING.md." $oldName $newName) -}}
    {{- else }}
      {{- $warnings = append $warnings (printf "[DEPRECATION] Receiver '%s' has been renamed to '%s'. Please update your values.yaml to use the new name — support for the old name will be removed in a future release. See UPGRADING.md." $oldName $newName) -}}
    {{- end }}
  {{- end }}
  {{- range $signal, $pipeline := $.Values.config.service.pipelines }}
    {{- if and $pipeline $pipeline.receivers }}
      {{- $hasOldPipelineRef := false -}}
      {{- range $pipeline.receivers }}
        {{- if or (eq . $oldName) (hasPrefix (printf "%s/" $oldName) .) }}
          {{- $hasOldPipelineRef = true -}}
        {{- end }}
      {{- end }}
      {{- if $hasOldPipelineRef }}
        {{- if $rewriteEnabled }}
          {{- $warnings = append $warnings (printf "[DEPRECATION] Pipeline '%s' references renamed receiver '%s'. It has been automatically rewritten to '%s' for this release. Please update your values.yaml — auto-rewrite will be removed in a future release. See UPGRADING.md." $signal $oldName $newName) -}}
        {{- else }}
          {{- $warnings = append $warnings (printf "[DEPRECATION] Pipeline '%s' references renamed receiver '%s'. Please update your values.yaml to use '%s' — support for the old name will be removed in a future release. See UPGRADING.md." $signal $oldName $newName) -}}
        {{- end }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
{{- range $oldName, $newName := (dig "detectors" dict $renames) }}
  {{- if dig $oldName "enabled" false $.Values.presets.resourceDetection }}
    {{- if $rewriteEnabled }}
      {{- $warnings = append $warnings (printf "[DEPRECATION] Detector '%s' has been renamed to '%s'. Your config has been automatically rewritten for this release. Please switch presets.resourceDetection.%s to presets.resourceDetection.%s in your values.yaml — auto-rewrite will be removed in a future release. See UPGRADING.md." $oldName $newName $oldName $newName) -}}
    {{- else }}
      {{- $warnings = append $warnings (printf "[DEPRECATION] Detector '%s' has been renamed to '%s'. Please switch presets.resourceDetection.%s to presets.resourceDetection.%s in your values.yaml — support for the old name will be removed in a future release. See UPGRADING.md." $oldName $newName $oldName $newName) -}}
    {{- end }}
  {{- end }}
{{- end }}
{{- join "\n" $warnings -}}
{{- end -}}

{{/*
List of upstream community OpenTelemetry Collector distributions that do NOT include
the profiling receiver. Among community images only `opentelemetry-collector-ebpf-profiler`
ships the receiver; custom/vendor distributions pass through.
Consumed by NOTES.txt to fail-fast when the profiling preset
is enabled with an incompatible community image.
See https://github.com/open-telemetry/opentelemetry-collector-releases/tree/main/distributions
*/}}
{{- define "opentelemetry-collector.profilingUnsupportedImages" -}}
- opentelemetry-collector
- opentelemetry-collector-contrib
- opentelemetry-collector-k8s
- opentelemetry-collector-otlp
{{- end }}
