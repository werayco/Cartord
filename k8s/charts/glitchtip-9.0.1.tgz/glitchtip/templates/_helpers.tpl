{{/* vim: set filetype=mustache: */}}

{{/*
Validate that removed values are not being used.
Fails with a helpful migration message if old values are detected.
*/}}
{{- define "glitchtip.validateValues" -}}
{{- $removed := list -}}

{{- if .Values.env -}}
  {{- if .Values.env.secret -}}
    {{- $removed = append $removed "env.secret is removed. Use glitchtip.secretKey or glitchtip.existingSecret for SECRET_KEY. Use extraEnvVars for other secrets." -}}
  {{- end -}}
  {{- if .Values.env.normal -}}
    {{- $removed = append $removed "env.normal is removed. Use glitchtip.domain for GLITCHTIP_DOMAIN. Use extraEnvVars on web/worker/migrationJob for other values." -}}
  {{- end -}}
{{- end -}}

{{- if .Values.existingSecret -}}
  {{- $removed = append $removed "existingSecret is removed. Use glitchtip.existingSecret for SECRET_KEY, or extraEnvVars for other values." -}}
{{- end -}}

{{- if .Values.web -}}
  {{- $removed = append $removed "The web.* section was flattened to the chart root. Move web.replicaCount/resources/autoscaling/budget/ingress/service/probes/etc. up one level. (web.embedWorker is also removed — the worker is now always embedded.)" -}}
{{- end -}}

{{- if .Values.worker -}}
  {{- $removed = append $removed "The worker section is removed. The worker is now always embedded in the web ASGI process; use the top-level replicaCount / resources / autoscaling to size it." -}}
{{- end -}}

{{- with .Values.migrationJob -}}
  {{- if .database -}}
    {{- $removed = append $removed "migrationJob.database is removed. Use glitchtip.maintenanceDatabase.existingSecret to give the migration job a privileged DB user (applied via MAINTENANCE_DATABASE_URL). If you don't need a separate user, leave it unset and the migration runs as glitchtip.database." -}}
  {{- end -}}
{{- end -}}



{{- if $removed -}}
  {{- fail (printf "\n\nREMOVED VALUES DETECTED (breaking changes):\n\n  - %s\n\nSee CHANGELOG for migration guide.\n" (join "\n  - " $removed)) -}}
{{- end -}}

{{/* Validate required database configuration */}}
{{- if and (not .Values.postgresql.enabled) (not .Values.glitchtip.database.existingSecret) -}}
  {{- fail "glitchtip.database.existingSecret is required when postgresql.enabled=false. Provide a secret containing DATABASE_URL." -}}
{{- end -}}

{{- end -}}

{{/*
Expand the name of the chart.
*/}}
{{- define "glitchtip.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "glitchtip.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "glitchtip.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "glitchtip.labels" -}}
helm.sh/chart: {{ include "glitchtip.chart" . }}
{{ include "glitchtip.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "glitchtip.selectorLabels" -}}
app.kubernetes.io/name: {{ include "glitchtip.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "glitchtip.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "glitchtip.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Resolve the image tag: explicit value if set, otherwise Chart.AppVersion.
*/}}
{{- define "glitchtip.image.tag" -}}
{{- .Values.image.tag | default .Chart.AppVersion -}}
{{- end -}}

{{- define "glitchtip.valkey.fullname" -}}
{{- if .Values.valkey.fullnameOverride -}}
{{- .Values.valkey.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name "valkey" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Set redis url (only used when valkey.enabled=true)
*/}}
{{- define "glitchtip.valkey.url" -}}
{{- if and (hasKey .Values.valkey "tls") .Values.valkey.tls.enabled -}}
rediss://
{{- else -}}
redis://
{{- end -}}
{{- if .Values.valkey.auth.password -}}
:{{ .Values.valkey.auth.password }}@
{{- end -}}
{{- template "glitchtip.valkey.fullname" . -}}:{{- template "glitchtip.valkey.port" . -}}/0
{{- end -}}

{{/*
Set redis port (only used when valkey.enabled=true)
*/}}
{{- define "glitchtip.valkey.port" -}}
6379
{{- end -}}

{{/*
Glitchtip shared environment variables (SECRET_KEY, GLITCHTIP_DOMAIN)
*/}}
{{- define "glitchtip.shared.env" -}}
- name: SECRET_KEY
  {{- if .Values.glitchtip.secretKey }}
  value: {{ .Values.glitchtip.secretKey | quote }}
  {{- else }}
  valueFrom:
    secretKeyRef:
      name: {{ required "one of glitchtip.existingSecret or glitchtip.secretKey is required" .Values.glitchtip.existingSecret }}
      key: {{ .Values.glitchtip.existingSecretKey }}
  {{- end }}
- name: GLITCHTIP_DOMAIN
  value: {{ .Values.glitchtip.domain | quote }}
{{- end -}}

{{/*
Database environment variables.
Usage: {{ include "glitchtip.database.env" . }}
Renders DATABASE_URL (always), plus READ_ONLY_DATABASE_URL and
MAINTENANCE_DATABASE_URL when configured under .Values.glitchtip.
*/}}
{{- define "glitchtip.database.env" -}}
{{- /* Resolve DATABASE_URL */ -}}
{{- $dbSecret := "" -}}
{{- $dbKey := "" -}}
{{- if .Values.postgresql.enabled -}}
  {{- $dbSecret = printf "%s-pg-app" (include "glitchtip.fullname" .) -}}
  {{- $dbKey = "uri" -}}
{{- else -}}
  {{- $dbSecret = .Values.glitchtip.database.existingSecret -}}
  {{- $dbKey = .Values.glitchtip.database.existingSecretKey | default "DATABASE_URL" -}}
{{- end -}}
- name: DATABASE_URL
  valueFrom:
    secretKeyRef:
      name: {{ $dbSecret }}
      key: {{ $dbKey }}

{{- /* Resolve READ_ONLY_DATABASE_URL */ -}}
{{- with .Values.glitchtip.readOnlyDatabase.existingSecret }}
- name: READ_ONLY_DATABASE_URL
  valueFrom:
    secretKeyRef:
      name: {{ . }}
      key: {{ $.Values.glitchtip.readOnlyDatabase.existingSecretKey | default "READ_ONLY_DATABASE_URL" }}
{{- end }}

{{- /* Resolve MAINTENANCE_DATABASE_URL */ -}}
{{- with .Values.glitchtip.maintenanceDatabase.existingSecret }}
- name: MAINTENANCE_DATABASE_URL
  valueFrom:
    secretKeyRef:
      name: {{ . }}
      key: {{ $.Values.glitchtip.maintenanceDatabase.existingSecretKey | default "MAINTENANCE_DATABASE_URL" }}
{{- end }}
{{- end -}}

{{/*
Valkey environment variables
*/}}
{{- define "glitchtip.valkey.env" -}}
{{- if or .Values.valkey.enabled .Values.glitchtip.valkey.existingSecret }}
- name: REDIS_URL
  valueFrom:
    secretKeyRef:
    {{- if .Values.glitchtip.valkey.existingSecret }}
      name: {{ .Values.glitchtip.valkey.existingSecret }}
      key: {{ .Values.glitchtip.valkey.existingSecretKey }}
    {{- else }}
      name: {{ include "glitchtip.fullname" . }}
      key: REDIS_URL
    {{- end }}
{{- end -}}
{{- end -}}